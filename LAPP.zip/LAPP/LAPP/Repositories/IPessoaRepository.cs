﻿using LAPP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAPP.Repositories
{
    public interface IPessoaRepository
    {

        public List<Pessoa> Get(); //GET ALL
        public Pessoa Get(int id); // GET ID
        public void Insert(Pessoa pessoa); //INSERT 
        public void Update(Pessoa pessoa); // UPDATE
        public void Delete(int id); // DELETE
        








    }


}
