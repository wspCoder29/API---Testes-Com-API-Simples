﻿using LAPP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using Microsoft.Data.SqlClient;
using Dapper;

namespace LAPP.Repositories
{
    public class PessoaRepository : IPessoaRepository
    {

        //IDbConnection pertence a System.Data
        private IDbConnection _connection;

        public PessoaRepository()
        {
            //PRECISA DO SqlClient package
            //CONNECTION STRING
            //Usar @
            _connection = new SqlConnection(@"Data Source=DESKTOP-U72UVTF;Initial Catalog=Pessoa;Integrated Security=True");

        }


        public List<Pessoa> Get()
        {
            return _connection.Query<Pessoa>("SELECT * FROM Pessoa").ToList();
        }



        public Pessoa Get(int id)
        {
            return _connection.QuerySingleOrDefault<Pessoa>("SELECT * FROM Pessoa WHERE id = @id", new { id = id });
        }


        public void Insert(Pessoa pessoa)
        {
            string sql = "INSERT INTO Pessoa(Nome, idade) VALUES (@Nome, @idade); SELECT CAST (SCOPE_IDENTITY()AS INT);";
            pessoa.id = _connection.Query<int>(sql, pessoa).Single();

        }

        //task e async e await

        public void Delete(int id)
        {
            _connection.Execute("DELETE FROM Pessoa WHERE id = @id", new { id = id });
        }



        public void Update(Pessoa pessoa)
        {
            string sql = "UPDATE Pessoa SET Nome = @Nome, idade = @idade, WHERE id = @id";

            _connection.Execute(sql, pessoa);

        }
        









    }




}
