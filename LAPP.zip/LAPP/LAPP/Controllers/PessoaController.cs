﻿using LAPP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LAPP.Model;

namespace LAPP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PessoaController : ControllerBase
    {
        private PessoaRepository _repository;
        public PessoaController()
        {
            _repository = new PessoaRepository();
        }



        //RETORNA TODOS OS USUÁRIOS
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_repository.Get()); // http - 200 OK
        }


        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var pessoa = _repository.Get(id);
            if (pessoa == null)
            {
                return NotFound(); //ERRO HTTP: 404 Not Found
            }
            return Ok(pessoa);
        }


        
        [HttpPost]
        public IActionResult Insert([FromBody] Pessoa pessoa)
        {
            _repository.Insert(pessoa);
            return Ok(pessoa);
        }

        
        [HttpPut]
        public IActionResult Update([FromBody] Pessoa pessoa)
        {
            _repository.Update(pessoa);
            return Ok(pessoa);
        }



        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _repository.Delete(id);
            return Ok();
        }

        


        //END CONTROLLER
    }
}
